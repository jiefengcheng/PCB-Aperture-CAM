Separate dependency-delivery correction after ABI5 audit of 06c146e.

Both supplied dependency manifests pin sexpdata==1.0.2, matching the exact already-installed and independently hash-matched parser. The unmodified licensed parser is included under vendor/ for offline use. No package was installed or upgraded. No reviewed source, original audit ZIP, runtime fingerprint, saved plan, copper geometry or acceptance receipt changed.

This local delivery addresses ABI5-001; it is outside the original audited snapshot and is not retroactively independently approved. ABI5-002 parser-byte fingerprint hardening remains a future separately versioned contract change. ABI5-003/004/005/006 scope and historical qualifications remain as recorded.
